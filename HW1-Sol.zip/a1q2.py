# Computes the minimum number of coins needed
def numCoins(dollars):
  cents=int(dollars*100) # this turns dollars into cents
  quarters=cents//25 
  cents=cents%25
  #this computes the remaining number of cents after quarters are removed
    
  dimes=cents//10
  cents=cents%10
   
  nickels=cents//5
  pennies=cents%5
    
  num_coins = quarters + dimes + nickels + pennies
  return num_coins

dollars =  float(input("Enter the amount you are owed in $: "))

print("The minimum number of coins the cashier can return is:", numCoins(dollars))
