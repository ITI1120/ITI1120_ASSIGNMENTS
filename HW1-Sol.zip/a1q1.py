def convertToKg(pounds, ounces):
    kg = (pounds * 16 + ounces) * 0.02835
    return kg

pounds = float(input("Enter the weight in pounds: "))
ounces = float(input("Enter the number of ounces: "))


print(pounds,"pounds and",ounces,"ounces is",convertToKg(pounds, ounces),"kg.")

  
