def lightYearsToSeconds(years): 
  seconds = years * 365.26 * 24 * 60 * 60
  return seconds

def secondsToDistance(seconds): 
  distance = seconds * 300000
  return distance

def distanceBetweenStars(distanceAl1, distanceAl2):
 sec1 = lightYearsToSeconds( distanceAl1 )
 sec2 = lightYearsToSeconds( distanceAl2 )
 distKm1 = secondsToDistance( sec1 )
 distKm2 = secondsToDistance( sec2 )
 return(distKm1 + distKm2)

y =  float(input("Input a number of light-years: "))
s = lightYearsToSeconds(y)
print("The number of seconds is", s)

dist = secondsToDistance(s)
print("The distance is", dist, "km.")

d1 =  float(input("Input the distance to the first star, in light years: "))
d2 =  float(input("Input the distance to the second star, in light years: "))
print("The distance between the two stars is", distanceBetweenStars(d1, d2), "km") 
 
