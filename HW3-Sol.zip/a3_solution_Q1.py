# COPYRIGHT 2018, Vida Dujmovic. All rights reserved.
# Any unauthorised distribution will constitute an infringement of copyright.

def count_pos(x): # version with for loop over elements
     '''(list)->int
      Returns the number of postive elements in the list of numbers x
      Precondition: x is a list of numbers
      '''
     counter = 0 # accumulator variable
     for item in x:
        if item > 0:
             counter = counter + 1
     return counter


def count_pos_v2(x):# a version with for loop over indices
     '''(list)->int
      Returns the number of postive elements in the list of numbers x
      Precondition: x is a list of numbers
      '''
     counter = 0
     i = 0
     for i in range(len(x)):
        if x[i] > 0 :
          counter = counter + 1
     return counter


def count_pos_v3(x): # a version with while loop over indices
     '''(list)->int
      Returns the number of postive elements in the list of numbers x
      Precondition: x is a list of numbers
      '''
     counter = 0
     i = 0
     while i < len(x):
        if x[i] > 0 :
          counter = counter + 1
        i = i + 1   
     return counter


raw_input = input("Please input a list of numbers separated by space: ").strip().split()
a=[]
for s in raw_input:
     a.append(float(s))

print("There are",count_pos(a), "positive numbers in your list.")






