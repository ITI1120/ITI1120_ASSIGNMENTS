﻿from a4q2Lib import *
    
def displayTable (tab):
    '''
    (list) -> None
    display the table of the game
    Preconditions: tab is a reference to an nxn array that contains '-', 'X' or 'O'
    The format is: 
        0 1 2
      0 - - O
      1 - X -
      2 - - X
    '''
    print("   ", end="")
    col = 0
    while col < len(tab): 
      print(col, end="  ")
      col += 1
    print()  
    row = 0  
    while row < len(tab):  
      print(row, end="")
      col = 0
      while col < len(tab[row]): 
        print(" ",tab[row][col], end="")
        col += 1
      print()
      row += 1

def play (tab, player):
    '''
    (list, str) -> None
    Play a step of the game
    Preconditions: tab is a reference to the n x n tab containing '-', 'X' and 'O'
    The player is either X or O
    tab is modified (an element has changed)              
    
    valid = False
                 
                 
    while not valid:   
        place = [-1,-1] # create a table with two elements
        while not((0 <= place[0] < len(tab)) and (0 <= place[1] < len(tab))):
          print ("player ",player, end="")
          print(", Provide the row and column from 0 to", (len(tab)-1), ": ")
          place[0] = int(input("Row: ")) # 
          place[1] = int(input("Column: "))
        #find a position that is not busy and contains '-‘             
        if tab[place[0]][place[1]] != '-':
          print("the position", place[0], place[1], "is busy
          valid = False
        else:
          valid = True             
          # put the player in the array 
          tab[place[0]][place[1]] = player 
    # No result
  

# Create the game table 
table = [['-','-','-'],['-','-','-'],['-','-','-']] # the only array used in the program.
    
response = input("Start a game (O or N): ");    
while response == 'o' or response == 'O': 
      eraseTable(table)  # prepare the game table
      winner = False  # initialize winner variable  
      while not winner: 
        displayTable(table) # display the game table
        play(table,'X')  # ask the player X to play
        winner = verifyWinner(table)  # did he win?
        if not winner
          # no winner, the other player can play
          displayTable(table) # dplay the game table
          play(table,'O')  # ask the player O to play
          winner = verifyWinner(table)  # did he win?
       
      displayTable(table) #  display the game table
      response = input("Start a game (O or N): ") # new game?
