﻿def eraseTable (tab):
   '''
   (list) -> None
   This function prepares the game table (array) 
   by putting '-' in all the elements.
   It does not create a new array
   Preconditions: tab is a reference to an nxn array that contains '-', 'X' or 'O'
   '''
      
   row = 0
   while row < len(tab):
      col = 0  
      while col < len(tab[row]): 
        tab[row][col] = '-'
        col += 1
      row += 1
   
      
def verifyWinner(tab):  
    '''(list) ->  bool
    * Preconditions: tab is a reference to an nxn array that contains '-', 'X' or 'O'
    * Verify if there is a winner.
    * Look for 3 X's and O's in a row, column, and diagonal.
    * If we find one, we display the winner (the message "Player X has won" 
    * or "Player O has won!") and returns True.
    * If there is a draw (verify it with the function testdraw),
    * display "It is a draw" and returns True.
    * If the game is not over, returns False.
    * The function call the functions testrows, testCols, testDiags
    * pour verifier s'il y a un gagnant.
    * Those functions returns the winner 'X' or 'O', or '-' if there is no winner.
    '''
    winnerAllorDraw = False
    winner = '-'   # to identify the winner
    winner = testRows(tab)
    if winner == '-' : 
      winner= testCols(tab)
      if winner == '-': 
        winner = testDiags(tab)
        if winner == '-': 
          if testDraw(tab): 
            print("Draw")
            winnerAllorDraw = True
    if winner != '-':  # announce the winner
      print("Playerr ", winner, "has won!")
      winnerAllorDraw = True
    return winnerAllorDraw

    
def testRows(tab):
   ''' (list) ->  str
   * verify if there is a winning row.
   * Look for three 'X' or three 'O' in a row.  
   * If they are found, the character 'X' or 'O' is returned, otherwise '-' is returned.
   * Preconditions: tab is a reference to an nxn array that contains '-', 'X' or 'O'
   '''
   winner = '-'
   row = 0 
   while row < len(tab):
      if tab[row][0] != '-':
        if tab[row][1] == tab[row][0] and tab[row][2] == tab[row][0]: 
          winner = tab[row][0]
          break
      row += 1    
   return winner
  
  
def testCols(tab):
   ''' (list) ->  str
   * verify a winning column.
   * look for three 'X' or three 'O' in a column.  
   * If it is the case the character 'X' or 'O' is returned, otherwise '-' is returned.
   * Preconditions: tab is a reference to an nxn array that contains '-', 'X' or 'O'
   '''
   winner = '-'
   col = 0 
   while col < len(tab):
      if(tab[0][col] != '-'):
        if( (tab[1][col] == tab[0][col]) and (tab[2][col] == tab[0][col])):
          winner = tab[0][col]
          break
      col += 1   
   return winner
  
   
def testDiags(tab):
   ''' (list) ->  str
   * Look for three 'X' or three 'O' in a diagonal.  
   * If it is the case, the character 'X' or 'O' is returned
   * otherwise '-' is returned.
   * Preconditions: tab is a reference to an nxn array that contains '-', 'X' or 'O'
   '''
   winner = '-'
   if( tab[1][1] != '-'):
      if( (tab[0][0] == tab[1][1]) and (tab[2][2] == tab[1][1])):
          winner = tab[1][1]
      else:  
          if((tab[0][2] == tab[1][1]) and (tab[2][0] == tab[1][1])):
             winner = tab[1][1]  
   return winner
   
  
def testDraw(tab):
   ''' (list) ->  bool
   * verify if there is a draw
   * check if all the array elements have X or O, not '-'.  
   * If we do not find find any '-' in the array, return True. 
   * If there is any '-', return false.
   * Preconditions: tab is a reference to an nxn array that contains '-', 'X' or 'O'
   '''
   drawGame = True
   row = 0
   while row < len(tab) and drawGame
      col = 0
      while col < len(tab[row]) and drawGame:
        if(tab[row][col] == '-'):
          drawGame = False
          break
        col +=1
      row +=1
   return drawGame
  
   

