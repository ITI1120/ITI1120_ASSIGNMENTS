﻿def add(m):
  ''' (list) -> none
       Precondition: m is a m x n array
       change the array elements by adding 1
  '''
  L = 0
  while L < len(m):
     C = 0
     while C < len(m[L]):
        m[L][C] += 1
        C = C + 1
     L = L + 1

def add_V2(m):
  ''' (list) -> list
       Precondition: m is a m x n array
       The result is a new n x m array
  '''
  L = 0
  m1 = []
  while L < len(m):
     C = 0
     m1.append([])
     while C < len(m[L]):
        m1[L].append(m[L][C]+1)
        C = C + 1
     L = L + 1
  return m1


print("Enter the array elements with spaces between columns.")
print("A row per line, and an empty line at he end.")
matrix = []
while True:
     line = input()
     if not line: break
     values = line.split()
     row = [int(val) for val in values]
     matrix.append(rangee)

print("The array is:")
print(matrix)
add(matrix)
print("After executing the function add, the array is:")
print(matrix)
print("with a new array created with add_V2:")   
matrix1 = add_V2(matrix)
print(matrix1)
print("After executing the function add_V2, the initial arrray is:")
print(matrix)


