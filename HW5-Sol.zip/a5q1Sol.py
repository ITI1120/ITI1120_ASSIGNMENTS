﻿from random import shuffle

class Blackjack:
 values={'1':1,'2':2,'3':3,'4':4,'5':5,'6':6,'7':7,'8':8,'9':9,'10':10,'J':10,'Q':10,'K':10,'A':11}
  
 def play(self):
  '''jour un jeu'''   
  d = GameOfCards()
  d.mix()
  
  bank = Main('bank')
  player = Main('player')

  # gives two cards to the player  and two to the bank
  for i in range(2):  
    player.addCard(d.getCard())
    bank.addCard(d.getCard())
  # Shows the hands
  bank.showMain()
  player.showMain()
  # as long as the player asks for a card!, the bank gets cards
  response = input('Card? Yes or no? (by default yes) ')
  while response in ['','y','Y','yes','Yes']:
    c = d.getCard()
    print("You have:")
    print(c)
    player.addCard(c)
    if self.total(player) > 21:
       print("You have passed 21. You have lost.")
       return   
    response = input('Card? Yes or no? (by default yes) ')
  # the bank plays with its rules  
  while self.total(bank) < 17:
    c = d.tireCarte()
    print("The bank has:")
    print(c)
    bank.addCard(c)
    if self.total(bank) > 21:
       print("The bank has passed 21. You have won.")
       return
  self.compare(bank, player)
      
 def total(self, main):
    ''' (Main) -> int
    calculate the sum of values of the cards in the main
    ''' 
    sum = 0
    numAs = 0
    for card in main.main:
          sum = sum + Blackjack.values[card.value]
          if Blackjack.values[card.value] == 'A':
              numAs += 1
    while sum > 21 and numAs > 0:
          sum -= 10
          numAs -=1
    return sum

 def compare(self, bank, player):
    ''' (Main, Main) -> bool
    Compare the player's main with the one of the bank
 and display the messages
    '''
    bankTotal = self.total(bank)
    playerTotal = self.total(player)
    if bankTotal > playerTotal:
       print('You have lost.')
    elif bankTotal < playerTotal:
       print('You have won.')   
    elif bankTotal == 21 and 2 == len(bank.main) < len(player.main):
       print('You have lost.')  # The bank has a blackjack
    elif (playerTotal == 21) and 2 == len(bank.main) < len(player.main):
       print('You have won.')  # The player has a blackjack
    else: print('Equality.')
       

class Card:
    '''represents a card to be played'''

    def __init__(self, value, color):
        '''(Card,str,str)->None        
        initialise la value et la color de la card'''
        self.value = value
        self.color = color  # heart, spade, diamond or club

    def __repr__(self):
        '''(card)->str
        returns a representation of the object'''
        return 'card('+self.value+', '+self.color+')'

    def __eq__(self, other):
        '''(card,card)->bool
        self == other if the value and color are the same'''
        return self.value == other.value and self.color == other.color

 class GameOfCards:
    '''represents a game of 52 cards'''
    # values and colors are variables of class
    values = ['2','3','4','5','6','7','8','9','10','J','Q','K','A']
    colors = ['\u2660', '\u2661', '\u2662', '\u2663']
    # colors is a set of 4 Unicode symbols that represent the 4 colors
    # heart, diamond, clubs and spade
    
    def __init__(self):
        'initializes the packet of 52 cards'
        self.packet = []          # empty to start
        for color in GameOfCards.colors: 
            for value in GameOfCards.values: # variables of class                # add a card of value and color
                self.packet.append(card(value,color))

    def getcard(self):
        '''(GameOfCards)->card
        distribute a card, the first of the packet'''
        return self.packet.pop()

    def mix(self):
        '''(GameOfCards)->None
        to mix the game of cards'''
        shuffle(self.packet)

    def __repr__(self):
        '''retourne une representation de l'objet'''
        return 'packet('+str(self.packet)+')'

    def __eq__(self, other):
        '''returnTrue if the packets have the same cards
           in the same order'''
        return self.packet == other.packet

    
class Main(object):
    '''represente une main des cards to be played'''
    def __init__(self, player):
        '''(Main, str)-> none
        initialize the player's name and the cards list being empty'''
        self.player = player
        self.main = []

    def addcard(self, card):
        '''(Main, card) -> None
        add a card in the hand (main)'''
        self.main.append(card)

    def showMain(self):
        '''(Main)-> None
        display the player's name and the main'''
        print('{}:'.format(self.player), end='')
        for card in self.main:
            val = card.value
            cou = card.color
            print('{:>4} {}'.format(val, cou), end = '')
        print()
        
    def __eq__(self, other):
        '''return True if the main(s)have the same cards
           in the same order'''
        return self.main == other.main

    def __repr__(self):
        '''return a representation of the object'''
        return str(self.main)
    
b = Blackjack()
b.play()

