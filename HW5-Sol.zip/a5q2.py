def stars(n):
  if (n != 0): 
    # We display a row of n stars
    for i in range(n):
      print('*', end='')
    print( )
    # We display the smaller diagram
    stars(n - 1)
    for i in range(n):
      print('*', end='')
    print( )       


   
def sumListPos_rec(l, n):
  if (n == 0): 
      s = 0
  else:
      if l[n-1] > 0:
        s = sumListPos_rec(l, n-1) + l[n-1]
      else:
        s = sumListPos_rec(l, n-1)
        
  return s   

