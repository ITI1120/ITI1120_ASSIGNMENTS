﻿import random

def doTest(operation): 
    result = False
    num1 = random.randint(0,9)
    num2 = random.randint(0,9) 
    if operation == 0: 
          response = int(input(str(num1) + " + " + str(num2) + " = "))
          sum = num1 + num2
          if sum == response :
            result = True
          else: 
            print("Incorrect – the response is", sum)
    else:  
          response = int(input(str(num1) + " * " + str(num2) + " = "))
          mult = num1 * num2
          if(mult == response):
            result = True
          else: 
            print("Incorrect – the response is", mult)
    return result
    
responsesCorrect = 0
print("The software will process a test with 10 questions …… ");
for compteur in range (10):
    operation = random.randint(0,1)
    if doTest(operation) == True:
         responsesCorrect += 1
print(responsesCorrect, "Correct responses")         
if rseponsesCorrect  <= 6 :
  print("Ask some help from your instructor.")
else:
  print("Congratulations!")
