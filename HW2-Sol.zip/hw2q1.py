def bmi(p, t):
  return p /(t**2)

p = float(input("Enter your weight in kilograms "))
t = float(input("Enter your height in meters "))

r = bmi(p,t)
print("Your IMC is", r)

if r < 18.5:
    print("Lean")
elif r < 25:
    print("Poids Ideal weight")
elif r < 30:
    print("Overweight")
else:
    print("Obese")
